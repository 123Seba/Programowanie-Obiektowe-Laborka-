import figury.*;

import java.util.Scanner;

public class Main {
    public static void main(String[]args){
        //zad1
/*Osoba o1=new Osoba("Jan", "Kowalski",20);
o1.pokazDane();*/
        //zad2
        //Student s1=new Student("Jan","Kowalski");
        /*Student s2=new Student("Programowanie");
        Student s3=new Student(12345);
        Student s4=new Student("Programowanie",2);

s1.display();
s2.display();
s3.display();
s4.display();*/
        //zad3
        /*Scanner input=new Scanner(System.in);
        Scanner input2=new Scanner(System.in);
        System.out.println("Podaj imie: ");
        s1.imie= input.nextLine();
        System.out.println("Podaj nazwisko: ");
        s1.nazwisko= input.nextLine();
        System.out.println("Numer indeksu: ");
        s1.nr_indeksu= input.nextInt();
        System.out.println("Nazwa specjalnosci: ");
        s1.nazwaSpecjalnosci= input2.nextLine();
        System.out.println("Rok studiow: ");
        s1.rokStudiow= input.nextInt();*/
    //zad4
        /*Kolo k1=new Kolo(2);
       k1.display();
        Prostokat p1=new Prostokat(2,4);
        p1.display();
        Szescian s1=new Szescian(2);
        s1.display();
        Prostopadloscian pr1=new Prostopadloscian(1,2,3);
        pr1.display();
        Kula ku1=new Kula(2);
        ku1.display();
        Stozek st1=new Stozek(1,2);
        st1.display();*/


    }
}
