public class DaneOsoba {
    //zad1
    Osoba o1=new Osoba("Jan", "Kowalski", 20);
    Osoba o2=new Osoba("Jan", "Kowalski", 20);
    Osoba o3=new Osoba("Jan", "Kowalski", 20);

}
