public class Main {
    public static void main(String[]args){
Wieloryb w1=new Wieloryb();
        w1.plyn();
        w1.wynurz();
        w1.zanurz();
        w1.przedstawSie();


    }
}
