public interface Plywanie {
    void plyn();
    void wynurz();
    void zanurz();
}
