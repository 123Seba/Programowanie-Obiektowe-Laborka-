public abstract class Zwierze {

    void przedstawSie(){
        System.out.println("Jestem zwierzeciem");
    }
}
