public class Statek implements Plywa{
    @Override
    public void plyn() {
        System.out.println("Plywam");
    }
}
