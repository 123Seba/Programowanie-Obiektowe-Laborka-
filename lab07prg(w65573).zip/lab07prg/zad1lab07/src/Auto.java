public class Auto implements Jedzie{
    @Override
    public void jade() {
        System.out.println("Jade po landzie");
    }
}
