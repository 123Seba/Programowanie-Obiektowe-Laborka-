public class Samolot implements Lata{
    @Override
    public void lec() {
        System.out.println("Latam");
    }
}
