public interface Jedzie {
    void jade();
}
