public interface Lata {

    void lec();

}
