public class Main {
    public static void main(String[]args){
        Statek s1=new Statek();
        s1.plyn();
        Samolot s2=new Samolot();
        s2.lec();
        Auto a1=new Auto();
        a1.jade();

    }
}
