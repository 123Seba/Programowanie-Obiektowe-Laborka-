public interface Plywa {

    void plyn();

}
