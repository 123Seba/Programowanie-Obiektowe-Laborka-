public class Main {
    public static void main(String[] args){

       //zad1.function1();
       //zad2.function2();
       // zad3.function3();
        //zad4.function4();
        //zad5.function5();
       // zad6.function6();
        zad7.function7();



    }
}
