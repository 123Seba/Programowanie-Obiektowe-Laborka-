public class zad3 {

    public static void function3(){
        String[] tab=new String[]{"ab","cd","ed"};
        for (String i: tab){
            System.out.println(i.toUpperCase());
        }//for

    }//function3


}
