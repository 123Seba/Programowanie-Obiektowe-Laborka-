public class Main {
    public static void main(String[]args){
Adres a1=new Adres(null,"Slonecna",1,"35-111");

    }
}
