public class NieprawidlowyAdresException extends Exception {
public NieprawidlowyAdresException(String errorMessage){
    super(errorMessage);
}
}
