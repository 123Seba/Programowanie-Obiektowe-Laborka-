public class BlednaWartoscDlaSilniException extends Exception{
    public BlednaWartoscDlaSilniException(String errorMessage){
        super(errorMessage);
    }
}
