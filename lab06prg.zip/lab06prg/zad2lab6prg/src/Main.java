public class Main {
    public static void main(String[]args){

        SamochodOsobowy so1=new SamochodOsobowy();
        Samochod s2=new Samochod();
        Samochod s1=new Samochod("Audi", "A5","4x4","Czarny",2020,20000);
        so1.opis();
        s2.opis();
        s1.opis();


    }}
