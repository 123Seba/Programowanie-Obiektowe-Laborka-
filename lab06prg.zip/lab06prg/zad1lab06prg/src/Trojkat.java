

public class Trojkat extends Figura {
   public double wys=0, podst=0;

    public Trojkat(double wys, double podst)
    {
        this.wys = wys;
        this.podst = podst;
    }
    public Trojkat(float wys, float podst, String kolor){
        this.wys = wys;
        this.podst = podst;
        this.kolor=kolor;
    }
}
