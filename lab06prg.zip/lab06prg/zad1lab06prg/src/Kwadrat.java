public class Kwadrat extends Prostokat{
double a;

    public Kwadrat(double wys, double szer) {
        super(wys, szer);
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

}
