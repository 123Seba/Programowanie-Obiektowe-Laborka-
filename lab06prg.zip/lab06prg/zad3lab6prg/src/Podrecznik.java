public class Podrecznik  {
    String etapEdukacji;
    String Przedmiot;
    Ksiazka k;

    public Podrecznik(String etapEdukacji, String przedmiot, Ksiazka k) {
        this.etapEdukacji = etapEdukacji;
        this.Przedmiot = przedmiot;
        this.k = k;
    }


}
