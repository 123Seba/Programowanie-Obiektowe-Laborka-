public class Ksiegarnia  {
    String nazwa;
    int iloscKsiazek;

    public void Opis(){
        System.out.println("Ksiegarnia "+nazwa);
    }

}
