public class Main {
    public static void main(String[]args){
Podrecznik p1=new Podrecznik("Liceum", "Fizyka",new Ksiazka("Nowak",2010,150));
Powiesc po1=new Powiesc("Historyczna",new Ksiazka("Kowalski",1920,200));
Ksiazka k1=new Ksiazka("Nowak",2000,50);
Ksiegarnia ksi1=new Ksiegarnia();
Klient kl1=(Klient) ksi1;



    }
}
