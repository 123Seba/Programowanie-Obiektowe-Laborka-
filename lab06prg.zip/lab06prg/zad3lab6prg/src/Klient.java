public class Klient extends Ksiegarnia {
    String imie;
    String nazwisko;
    int wiek;
    int iloscWypozyczonychKsiazek;

    public void dane(){
        System.out.println("Imie: "+imie);
        System.out.println("Nazwisko: "+nazwisko);
        System.out.println("Wiek: "+wiek);
        System.out.println("Liczba wypozyczonych ksiazek: "+iloscWypozyczonychKsiazek);
    }



}
